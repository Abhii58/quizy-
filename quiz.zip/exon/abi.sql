-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 06, 2017 at 11:50 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `abi`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `email`, `password`) VALUES
(1, 'ab150@gmail.com', '123456'),
(2, 'ab50@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `eid` text NOT NULL,
  `title` varchar(100) NOT NULL,
  `right` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `time` bigint(20) NOT NULL,
  `intro` text NOT NULL,
  `tag` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`eid`, `title`, `right`, `wrong`, `total`, `time`, `intro`, `tag`, `date`) VALUES
('6b1', 'web technology', 2, 1, 10, 5, '', 'web tech', '2022-06-23 09:03:59'),
('1ec', 'Php Coding', 2, 1, 10, 5, '', 'PHP', '2022-06-23 09:06:12'),
('b93', 'C++ Coding', 2, 1, 10, 5, '', 'c++', '2022-06-23 09:09:03'),
('o21', 'Networking', 2, 1, 10, 5, '', 'networking', '2022-06-23 09:09:03' ),
('ex5',  'Cyber_Law', 4, 1, 10, 5, '', 'cyber-law', '2022-06-23 09:09:03'),
('ex6',  'software testig', 4, 1, 10, 5, '', 'testing', '2022-06-23 09:09:03');


-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `eid` text NOT NULL,
  `qid` text NOT NULL,
  `qns` text NOT NULL,
  `choice` int(10) NOT NULL,
  `sn` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`eid`, `qid`, `qns`, `choice`, `sn`) VALUES
('6b1', 'zxa2', '________ keyword is used to declare variables in javascript', 4, 1),
('6b1', 'zxa3', 'what is permission for view only for other??', 4, 2),
('6b1', 'zxa11', 'Which of the following can read and render HTML web pages', 4, 3),
('6b1', 'zxa12', 'Identify the range of byte data types in JavaScript.', 4, 4),
('6b1', 'zxa13', 'The latest HTML standard is', 4, 5),
('6b1', 'zxa14', 'Why were cookies designed?', 4, 6),
('6b1', 'zxa15', 'What are variables used in JavaScript programs', 4, 7),
('6b1', 'zxa16', 'Simple network management protocol uses which of the following port number', 4, 8),
('6b1', 'zxa17', 'Full form of W3C is _____________', 4, 9),
('6b1', 'zxa18', 'Which of the following attribute is used for merging two or more adjacent columns?', 4, 10),
('1ec', 'zxa4', 'what is command for print in php??', 4, 1),
('1ec', 'zxb4', 'PHP stands for -', 4, 2),
('1ec', 'zxb5', 'Who is known as the father of PHP?', 4, 3),
('1ec', 'zxb6', 'Which of the following is not a variable scope in PHP?', 4, 4),
('1ec', 'zxb7', 'Which of the following is correct to add a comment in php?', 4, 5),
('1ec', 'zxb8', 'Which of the following is used to display the output in PHP?', 4, 6),
('1ec', 'zxb9', 'Which of the following function displays the information about PHP and its configuration?', 4, 7),
('1ec', 'zxb0', 'Which of the following function is used to find files in PHP?', 4, 8),
('1ec', 'zxb11', 'Which of the following function is used to unset a variable in PHP?', 4, 9),
('1ec', 'zxa5', 'which is a variable of php??', 4, 10),
('b93', 'zxa6', 'what is correct statement in c++??', 4, 1),
('b93', 'zxa7', 'which command is use for print the output in c++?', 4, 2),
('b93', 'zxb1', 'Which of the following is the correct syntax to add the header file in the C++ program?', 4, 3),
('b93', 'zxb2', 'The C++ language is ______ object-oriented language.', 4, 4),
('b93', 'zxb3', 'Which of the following is the correct syntax for declaring the array?', 4, 5),
('b93', 'zxb13', 'Which of the following is the correct identifier?', 4, 6),
('b93', 'zxb14', 'Which of the following is the address operator?', 4, 7),
('b93', 'zxb15', 'The programming language that has the ability to create new data types is called__________', 4, 8),
('b93', 'zxb16', 'Which of the following is the original creator of the C++ language?', 4, 9),
('b93', 'zxb17', 'Which of the following is the correct syntax to read the single character to console in the C++ language?', 4, 10),
('o21', 'zxa8', 'what is correct mask for A class IP???', 4, 1),
('o21', 'zxa9', 'which is not a private IP??', 4, 2),
('o21', 'zxa21', 'Which of these is a standard interface for serial data transmission?', 4, 3),
('o21', 'zxa22', 'Which of the following transmission directions listed is not a legitimate channel?', 4, 4),
('o21', 'zxa23', 'What kind of transmission medium is most appropriate to carry data in a computer network that is exposed to electrical interferences?', 4, 5),
('o21', 'zxa24', 'A collection of hyperlinked documents on the internet forms the ?', 4, 6),
('o21', 'zxa25', 'The location of a resource on the internet is given by its?', 4, 7),
('o21', 'zxa26', 'The term HTTP stands for?', 4, 8),
('o21', 'zxa27', 'A proxy server is used as the computer?', 4, 9),
('o21', 'zxa28', 'Which software prevents the external access to a system?', 4, 10),
('ex5', 'xca1', 'tampering with Computer Source Documents is ______ offence', 4, 1),
('ex5', 'xca2', 'which Section deals with cyber terrorism ?', 4, 2),
('ex5', 'xca3', 'amendment to IT Act 2000 came into effect on _________?', 4, 3),
('ex5', 'xca4', 'in which year Indias IT Act came into existence?', 4, 4),
('ex5', 'xca5', 'which one option is not a type of cybercrime?', 4, 5),
('ex5', 'xca51', 'The first Draft of Information Technology Act was drafted in the name of', 4, 6),
('ex5', 'xca52', 'The draft of IT Act 2000 was first drafted by', 4, 7),
('ex5', 'xca53', 'An appeal against the order of the Cyber Appellant Tribunal is possible', 4, 8),
('ex5', 'xca54', 'Cyber offenses are the unlawful acts which are carried in a very sophisticated manner in which the computer is', 4, 9),
('ex5', 'xca55', '________ is when small attacks add up to one major attack that can go undetected due to the nature of this type of cyber crime', 4, 10),
('ex6', 'xca6', 'Which of the following testing is also known as white-box testing?', 4, 1),
('ex6', 'xca7', 'Which of the following testing is related to the boundary value analysis?', 4, 2),
('ex6', 'xca8', 'Functional testing is a ------?', 4, 3),
('ex6', 'xca9', 'What are the different levels of Testing?', 4, 4),
('ex6', 'xcb1', 'Which of the following is not a part of STLC (Software Testing Life Cycle)?', 4, 5),
('ex6', 'xcb2', 'In which environment we can performed the Beta testing?', 4, 6),
('ex6', 'xcb3', 'What is error guessing in software testing?', 4, 7),
('ex6', 'xcb4', 'After which phase, we can proceed to the white box testing?', 4, 8),
('ex6', 'xcb5', 'Which of the following is not another name of white box testing?', 4, 9),
('ex6', 'xcb6', 'The test levels are performed in which of the following order?', 4, 10);




-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `qid` varchar(50) NOT NULL,
  `option` varchar(5000) NOT NULL,
  `optionid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`qid`, `option`, `optionid`) VALUES
('zxa2', 'var', 'er1'),
('zxa2', 'dim', 'er2'),
('zxa2', 'string', 'er3'),
('zxa2', 'none of the above', 'er4'),
('zxa3', '751', 'er5'),
('zxa3', '752', 'er6'),
('zxa3', '754', 'er7'),
('zxa3', '755', 'er8'),
('zxa11', 'server', 'er11'),
('zxa11', 'head tak', 'er12'),
('zxa11', 'web browser', 'er13'),
('zxa11', 'None of the above', 'er14'),
('zxa12', '-10 to 9', 'er15'),
('zxa12', '-128 to 127', 'er16'),
('zxa12', '-32768 to 32768', 'er17'),
('zxa12', '-21473847 to 21473847', 'er18'),
('zxa13', 'HTML4.0', 'er19'),
('zxa13', 'HTML5.0', 'er20'),
('zxa13', 'XML', 'er21'),
('zxa13', 'SGML', 'er22'),
('zxa14', 'for server side programming', 'er23'),
('zxa14', 'for client side programming', 'er24'),
('zxa14', 'both a and b', 'er25'),
('zxa14', 'none', 'er26'),
('zxa15', 'varying randomly', 'er27'),
('zxa15', 'storing,numbers,dates and other values', 'er28'),
('zxa15', 'use header file', 'er29'),
('zxa15', 'none of above', 'er30'),
('zxa16', '164', 'er31'),
('zxa16', '163', 'er32'),
('zxa16', '160', 'er33'),
('zxa16', '161', 'er34'),
('zxa17', 'world wide website community', 'er35'),
('zxa17', 'world wide web community', 'er36'),
('zxa17', 'world wide website consortium', 'er37'),
('zxa17', 'world wide web consortium', 'er38'),
('zxa18', 'rowspan', 'er39'),
('zxa18', 'cellspacing', 'er40'),
('zxa18', 'colspan', 'er41'),
('zxa18', 'cellpadding', 'er42'),
('zxa4', 'echo', 'er9'),
('zxa4', 'print', 'fr1'),
('zxa4', 'printf', 'fr2'),
('zxa4', 'cout', 'fr3'),
('zxb4', 'Pretext Hypertext Preprocessor', '13zx'),
('zxb4', 'Personal Home Processor', '14zx'),
('zxb4', ' Hypertext Preprocessor', '15zx'),
('zxb4', 'None of the above', '16zx'),
('zxb5', 'Rasmus Lerdrof', '17zx'),
('zxb5', 'List barley', '18zx'),
('zxb5', 'Drek Kolkevi', '19zx'),
('zxb5', 'None of the above', '20zx'),
('zxb6', 'Local', '21zx'),
('zxb6', 'Static', '22zx'),
('zxb6', 'Global', '23zx'),
('zxb6', 'Extern', '24zx'),
('zxb7', '& …… &', '25zx'),
('zxb7', '// ……', '26zx'),
('zxb7', '/* …… */', '27zx'),
('zxb7', 'both B and C', '28zx'),
('zxb8', 'Echo', '29zx'),
('zxb8', 'print', '30zx'),
('zxb8', 'both a and b', '31zx'),
('zxb8', 'write', '32zx'),
('zxb9', 'php_info()', '33zx'),
('zxb9', 'phpinfo()', '34zx'),
('zxb9', 'info()', '35zx'),
('zxb9', 'none of the above', '36zx'),
('zxb0', 'fold()', '37zx'),
('zxb0', 'file()', '38zx'),
('zxb0', 'globe()', '39zx'),
('zxb0', 'None of the above', '40zx'),
('zxb11', 'unset()', '41zx'),
('zxb11', 'delete()', '42zx'),
('zxb11', 'unlink()', '43zx'),
('zxb11', 'None of the above', '44zx'),
('zxa5', 'int a', 'fr4'),
('zxa5', '$a', 'fr5'),
('zxa5', 'long int a', 'fr6'),
('zxa5', 'int a$', 'fr7'),
('zxa6', 'cin>>a;', 'fr8'),
('zxa6', 'cin<<a;', 'fr9'),
('zxa6', 'cout>>a;', 'gr0'),
('zxa6', 'cout<a;', 'gr1'),
('zxa7', 'cout', 'gr2'),
('zxa7', 'cin', '4gr'),
('zxa7', 'print', '3gr'),
('zxa7', 'printf', '2gr'),
('zxb1', '#include<userdefined>', '1zx'),
('zxb1', '#include "userdefined.h"', '2zx'),
('zxb1', '<include> "userdefined.h"', '3zx'),
('zxb1', 'Both A and B', '4zx'),
('zxb2', 'Pure Object oriented', '5zx'),
('zxb2', 'Semi Object-oriented or Partial Object-oriented', '6zx'),
('zxb2', 'Not object oriented', '7zx'),
('zxb2', 'None of the above', '8zx'),
('zxb3', 'init array []', '9zx'),
('zxb3', 'Array[5];', '0zx'),
('zxb3', 'both a and b', '11zx'),
('zxb3', 'int array [5];', '12zx'),
('zxb13', '$var_name', 'ans1'),
('zxb13', 'VAR_123', 'ans2'),
('zxb13', 'varname@', 'ans3'),
('zxb13', 'none of the above', 'ans4'),
('zxb14', '@', 'ans5'),
('zxb14', '#', 'ans6'),
('zxb14', '&', 'ans7'),
('zxb14', '%', 'ans8'),
('zxb15', 'oevrloaded', 'ans9'),
('zxb15', 'encapsulated', 'ans10'),
('zxb15', 'Reprehensible', 'ans0'),
('zxb15', 'extensible', 'ans11'),        
('zxb16', 'Dennis Ritchie', 'ans13'),
('zxb16', 'Ken thompson', 'ans14'),
('zxb16', 'Bjarne Stroustrup', 'ans15'),
('zxb16', 'Brian Kernighan', 'ans16'),
('zxb17', 'Read ch()', 'ans17'),
('zxb17', 'Getline vh()', 'ans17'),
('zxb17', 'Get(ch)', 'ans18'),
('zxb17', 'Scanf(ch)', 'ans19'),
('zxa8', '255.0.0.0', '1gr'),
('zxa8', '255.255.255.0', 'gr9'),
('zxa8', '255.255.0.0', 'gr8'),
('zxa8', 'none of these', 'gr7'),
('zxa9', '192.168.1.100', 'gr6'),
('zxa9', '172.168.16.2', 'gr5'),
('zxa9', '10.0.0.0.1', 'gr4'),
('zxa9', '11.11.11.11', 'gr3'),
('zxa21', 'ASCII', 'ans21'),
('zxa21', 'RS232C', 'ans21'),
('zxa21', '2', 'ans22'),
('zxa21', 'Centronics', 'ans23'),
('zxa22', 'simplex', 'ans26'),
('zxa22', 'half duplex', 'ans27'),
('zxa22', 'full duplex', 'ans28'),
('zxa22', 'Double Duplex', 'ans28'),   
('zxa23', 'Unsheilded twisted pair', 'ans29'),
('zxa23', 'Opticalfiber', 'ans30'),
('zxa23', 'Coaxial cable', 'ans31'),
('zxa23', 'Microwave', 'ans32'),
('zxa24', 'World Wide Web (WWW)', 'ans33'),
('zxa24', 'E-mail system', 'ans34'),
('zxa24', 'Mailing text', 'ans35'),
('zxa24', 'Hyper text markup language', 'ans36'),
('zxa25', 'Protocol', 'ans37'),
('zxa25', 'URL', 'ans38'),
('zxa25', 'E-mail address', 'ans39'),
('zxa25', 'ICQ', 'ans40'),
('zxa26', 'Hyper terminal tracing program', 'ans41'),
('zxa26', 'Hyper text trasfer protocol', 'ans42'),   
('zxa26', 'Hyper text trcing protocol', 'ans43'),
('zxa26', 'Hyper text trcing program', 'ans44'),
('zxa27', 'with external access', 'ans45'),
('zxa27', 'acting as a backup', 'ans46'),
('zxa27', 'performing file handling', 'ans47'),
('zxa27', 'accessing user permissions', 'ans48'),
('zxa28', 'firewall', 'ans49'),
('zxa28', 'gateway', 'ans50'),
('zxa28', 'router', 'ans51'),
('zxa28', 'virus checker', 'ans52'),
('xca1', 'Bailable', 'nr1'),
('xca1', 'Non-cognigable', 'nr2'),
('xca1', 'Non-bailable', 'nr3'),
('xca1', 'both (a) and (c)', 'nr4'),
('xca2', '66f', 'nr5'),
('xca2', '66a', 'nr6'),
('xca2', '66b', 'nr5a'),
('xca2', '66d', 'nr5b'),
('xca3', '3 july 2005', 'nr6a'),
('xca3', '2 oct. 2008', 'nr6b'),
('xca3', '27 oct. 2009', 'fr6c'),
('xca3', '9 nov. 2008', 'fr6d'),
('xca4', '2001', 'nr7d'),
('xca4', '2003', 'nr8a'),
('xca4', '2004', 'nr9a'),
('xca4', '2000', 'nr1a'),
('xca5', 'data theft', 'nr1b'),
('xca5', 'installing antivirus', 'nr1c'),
('xca5', 'forgery', 'nr1d'),
('xca5', 'damage system and data', 'nr1e'),
('xca51', 'IT act', 'ans55'),
('xca51', 'Electronic Communication Act', 'ans56'),
('xca51', 'E-comerce act', 'ans57'),
('xca51', 'E-comerce bill', 'ans58'),
('xca52', 'Ministry of IT of Government of India', 'ans59'),
('xca52', 'Ministry of Commerce, Government of India', 'ans60'),
('xca52', 'Ministry of Law, Government of India', 'ans61'),
('xca52', 'Committee Appointed for this', 'ans62'),
('xca53', 'in any district court', 'ans63'),
('xca53', 'In Higher tribunal', 'ans64'),
('xca53', 'only in high court', 'ans65'),
('xca53', 'only in supreme court', 'ans66'),
('xca54', 'tool', 'ans67'),
('xca54', 'target', 'ans68'),
('xca54', 'both tool and target', 'ans69'),
('xca54', 'none of above', 'ans70'),
('xca55', 'Data diddling', 'ans72'),
('xca55', 'Virus attack', 'ans73'),
('xca55', 'Trojan attack', 'ans74'),
('xca55', 'Salami attacks', 'ans75'),
('xca6', 'Error guessing technique', 'km1a'),
('xca6', 'Design based testing', 'km3a'),
('xca6', 'Structural testing', 'km4a'),
('xca6', 'None of above', 'km5a'),
('xca7', 'Black box and white box testing', 'km6a'),
('xca7', 'Black box testing', 'km7a'),
('xca7', 'White box testing', 'km8a'),
('xca7', 'None of the above', 'km9a'),
('xca8', 'test design technique', 'km0a'),
('xca8', 'Test level', 'km2a'),
('xca8', 'SDLC model', 'km1b'),
('xca8', 'Test type', 'km2b'),
('xca9', 'Integration testing', 'km3b'),
('xca9', 'System testing', 'km4b'),
('xca9', 'Unit testing', 'km5b'),
('xca9', 'All of above', 'km6b'),
('xcb1', 'Testing planning', 'km7b'),
('xcb1', 'Requirment gathering', 'km8b'),
('xcb1', 'Testing clouser', 'km9b'),
('xcb1', 'test design', 'km0b'),
('xcb2', 'User and developers end', 'km10b'),
('xcb2', 'Devloper end', 'km11b'),
('xcb2', 'User end', 'km12b'),
('xcb2', 'None of the above', 'km13b'),
('xcb3', 'Test control management techniques', 'km14b'),
('xcb3', 'Test varification techniques', 'km15b'),
('xcb3', 'Test execution technique', 'km16b'),
('xcb3', ' data management techniques', 'km17b'),
('xcb4', 'After the installation phase', 'km18b'),
('xcb4', 'after designing phase', 'km19b'),
('xcb4', 'after SRS creation', 'km20b'),
('xcb4', 'after coding phase', 'km21b'),
('xcb5', 'structural testing', 'km22b'),
('xcb5', 'Behavioral testing', 'km23b'),
('xcb5', 'glass box testing', 'km24b'),
('xcb5', 'None of the mentioned', 'km25b'),
('xcb6', 'Unit, Integration, System, Acceptance', 'km26b'),
('xcb6', 'Unit, Integration, Acceptance, System', 'km27b'),
('xcb6', 'It is based on the nature of the project', 'km28b'),
('xcb6', 'Unit, System, Integration, Acceptance', 'km29b');











-- -------------------------------------------------------


--
-- Table structure for table `answer`
--

CREATE TABLE `answer` (
  `qid` text NOT NULL,
  `ansid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`qid`, `ansid`) VALUES
('zxa2', 'er1'),
('zxa3', 'er6'),
('zxa11', 'er13'),
('zxa12', 'er16'),
('zxa13', 'er20'),
('zxa14', 'er23'),
('zxa15', 'er28'),
('zxa16', 'er34'),
('zxa17', 'er38'),
('zxa18', 'er41'),
('zxa4', 'er9'),
('zxb4', '15zx'),
('zxb5', '17zx'),
('zxb6', '24zx'),
('zxb7', '28zx'),
('zxb8', '31zx'),
('zxb9', '34zx'),
('zxb0', '39zx'),
('zxb11', '41zx'),
('zxa5', 'fr5'),
('zxa6', 'fr8'),
('zxa7', '4gr'),
('zxb1', '4zx'),
('zxb2', '6zx'),
('zxb2',  '12zx'),
('zxb13', 'ans2'),
('zxb14', 'ans7'),
('zxb15', 'ans11'),
('zxb16', 'ans15'),
('zxb17', 'ans18'),
('zxa8', '1gr'),
('zxa9', 'gr5'),
('zxa21', 'ans21'),
('zxa22', 'ans28'),
('zxa23', 'ans32'),
('zxa24', 'ans33'),
('zxa25', 'ans38'),
('zxa26', 'ans42'), 
('zxa27', 'ans45'),
('zxa28', 'ans49'),
('xca1', 'fr1'),
('xca2', 'nr5'),
('xca3', 'fr6c'),
('cxa4', 'nr1a'),
('cxa5', 'nr1c'),
('xca51', 'ans57'),
('xca52', 'ans61'),
('xca53', 'ans65'),
('xca54', 'ans69'),
('xca55', 'ans75'),
('xca6', 'km4a'),
('xca7', 'km7a'),
('xca8', 'km2b'),
('xca9', 'km6b'),
('xcb1', 'km8b'),
('xcb2', 'km12b'),
('xcb3', 'km17b'),
('xcb4', 'km21b'),
('xcb5', 'km23b'),
('xcb6', 'km28b');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` text NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `feedback` varchar(500) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `subject`, `feedback`, `date`, `time`) VALUES
('55846be776610', 'testing', 'abhishek@gmail.com', 'testing', 'testing stART', '2015-06-19', '09:22:15pm'),
('5584ddd0da0ab', 'netcamp', 'ram10@gmail.com', 'feedback', ';mLBLB', '2015-06-20', '05:28:16am');


-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `email` varchar(50) NOT NULL,
  `eid` text NOT NULL,
  `score` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `right` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`email`, `eid`, `score`, `level`, `right`, `wrong`, `date`) VALUES
('ram10@gmail.com', '1ec', 4, 2, 2, 0, '2015-06-23 09:31:26'),
('rahul67@gmail.com', '6b1', 4, 2, 2, 0, '2015-06-23 13:32:09'),
('suraj10@gmail.com', 'b93', 1, 2, 1, 1, '2015-06-24 03:22:38');

-- --------------------------------------------------------







--
-- Table structure for table `rank`
--

CREATE TABLE `rank` (
  `email` varchar(50) NOT NULL,
  `score` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rank`
--

INSERT INTO `rank` (`email`, `score`, `time`) VALUES
('ashu@gmail.com', 9, '2015-06-24 03:22:38'),
('nikhil@gmail.com', 1, '2015-06-23 16:11:50');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` varchar(50) NOT NULL,
  `gender` varchar(5) NOT NULL,
  `college` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mob` bigint(20) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `gender`, `college`, `email`, `mob`, `password`) VALUES
('Ankit', 'M', 'MIT rishekesh', 'ankit20@gmail.com', 7785068889, 'e10adc3949ba59abbe56e057f20f883e'),
('Suraj', 'M', 'NIT dehradun', 'surajkp10@gmail.com', 7785068889, 'e10adc3949ba59abbe56e057f20f883e'),
('ankita', 'f', 'OIMT', 'ankita78@gmail.com', 11, 'e10adc3949ba59abbe56e057f20f883e'),
('Vikash', 'M', 'DU vikash9875@gmail.com', 'vikash@gmail.com', 7785068889, 'e10adc3949ba59abbe56e057f20f883e');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
